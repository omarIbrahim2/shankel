<?php

namespace App\Http\Livewire\Web\Suppliers;

use Livewire\Component;

class Suppliers extends Component
{
    public function render()
    {
        return view('livewire.web.suppliers.suppliers');
    }
}
