<?php

namespace Database\Seeders;

use App\Models\Addvert;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Shankl',
            'email' => 'shankl@superadmin.com',
            'password' => Hash::make('123456'),
            'role_id' => 1
        ]);

        User::create([
            'name' => 'omar',
            'email' => 'omar@admin.com',
            'password' => Hash::make('1234567'),
            'role_id' => 2
        ]);

    }
}
