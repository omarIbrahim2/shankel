<?php
return[
    "comment" => "Comment",
    "editComment" => "Edit Comment" ,
    "cls" => "Close",
    "edit" => "Edit",
    'deleteMsg' => "comment deleted successfully",
];