<?php

return[
    "shanklAdd" => "Amman - Wasfi Al-Tal Street - Al-Waha Roundabout", 
    "follow" => "Follow Us",
    "contact" => "Contact Us",
    "name" => "Name",
    "email" => "Email",
    "sub" => "Subject",
    "mess" => "Message",
    "send" => "Send Message",
    "comment" => "Comment",
    "leaveCom" => "Leave Comment",
    "delete" => "Delete",
    "update" => "Update",
    "messSucc" => "Message Sent Successfully",
    "messfail" => "Failed In Sending Message, Please Try Again",
];