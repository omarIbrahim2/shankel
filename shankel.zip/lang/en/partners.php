<?php

return [
"partners" => "Partners",

];