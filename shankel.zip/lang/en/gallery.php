<?php
return[
    "title_en" => "English Title",
    "title_ar" => "Arabic Title",
];