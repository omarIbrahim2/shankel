<?php
return[
    "name_en" => "Name",
    "name_ar" => "الإسم",
    "desc_en" => "Description",
    "desc_ar" => "الوصف",
    "upload" => "Upload Image",
    "price" => "Price" ,
    "update" => "Update",
    "add" => "Add",
    "book" => "Add to cart",
    'remove' => 'remove from cart',
    'quantity' => 'Quantity',
    "addImage" => 'Add service Images',
    'updateImages' => 'Update Service Images',
    'serviceDeleteMsg' => 'service deleted successfully',
    'Delete' => 'Delete',
    'AddServMsg' => 'service created successfully',
];