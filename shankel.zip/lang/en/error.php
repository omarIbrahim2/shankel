<?php

return [
 
    'errorMsg' => 'error happened ..!',
 

];