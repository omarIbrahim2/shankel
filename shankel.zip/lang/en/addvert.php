<?php

return[
    "title" => "Title",
    "title_en" => "English Title",
    "title_ar" => "Arabic Title",
    "desc" => "Description",
    "desc_en" => "English Description",
    "desc_ar" => "Arabic Description",
    "upload" => "Upload Image",
    "update" => "Update",
    "add" => "Add",
    "addverts" => "Addvertisments",
];
