<?php

return[

  "updateMsg" => 'data updated successfully',

];