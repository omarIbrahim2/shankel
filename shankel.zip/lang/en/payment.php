<?php

return [
"wrong" => "no seats availiable",
"error" => 'error happened , please try again ..!',
'empty' => 'cart is empty',
'amount' => "paid amount cannot be zero",
];