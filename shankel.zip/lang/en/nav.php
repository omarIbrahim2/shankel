<?php

return [

"Home" => "Home",
"Profile" => "Profile",
"Schools" => "Schools",
"Teachers" => "Teachers",
"Suppliers" => "Suppliers",
"Services" => "Services",
"Events" => "Events",
"Addverts" => "Adds",
'dash' => "Dashboard",
];
