<?php

return [
  "AboutUs" => "About Us",
  "OurVision" => "Our Vision",
  "OurMission" => 'Our Mission',
  "WhyChooseUs" => "Why Choose Us",
  "gallery" => "Gallery",
  'recentSer' => 'Recent Services',
  'famousSch' => 'Famous Schools',
  'showMore' => 'Show More',
  'features' => 'Features',
  'featureTitle'=> 'Lorem Ipsum Dolor Sit Amet Consectetur, Adipisicing Elit. Hic Eum Laborum Dignissimos Accusantium Quaerat Odio Commodi Quos Quisquam! Ad, Dicta.',
  'SecurePayment' => 'Secure Payment',
  'SecurePaymentContent' => 'Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Numquam, Tempora.',
  'EasyUsage' => 'Easy Usage',
  'EasyUsageContent' => 'Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Numquam, Tempora.',
  'EasyBooking' => 'Easy Booking',
  'EasyBookingContent' => 'Lorem Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Numquam, Tempora.',
  'faq' => 'FAQ',
  'faqs' => 'Frequently Asked Questions',
  'faq1Content' => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod a nulla, eaque ab
  dignissimos ut voluptatibus! Beatae perferendis, voluptatem exercitationem
  tenetur inventore neque officia odit?',
  'faq2Title' => 'How I use',
  'faq2Content' => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod a nulla, eaque ab
  dignissimos ut voluptatibus! Beatae perferendis, voluptatem exercitationem
  tenetur inventore neque officia odit?',
  'faq1Title' => 'General'
];
