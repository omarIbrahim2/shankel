<?php

return [

   "Sign Up" => "Sign Up",

   "name" => "Name",

   "email" => "Email",

   "password" => "Password",

   "confirm_password" => "Confirm Password",

   "phone" => "Phone",

   "city" => "City",

   'area' => "Area",


   "title" => "Title",
     
   "price" => "Price",

   "subject" => 'Subject',
   "Add Child" => "Add Child",
   "changepass" => "password changed successfully",

   "selectUser" => "Select User",

   "Parent" => 'Parent',

   "Teacher" => "Teacher",

   "School" => "School",

   "Supplier" => "Supplier",
   "center" => "Center",
   "kg" => "Kindergarten",
   "nursery" => "nursery",
   "LoginToShankl" => "Login to Shankl",
   "ClickHere" => "Click Here",
   "signUpAs" => "Sign Up As",
];