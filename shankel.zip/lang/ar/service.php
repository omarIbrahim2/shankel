<?php
return[
    "name" => "الإسم",
    "desc" => "الوصف",
    "upload" => "إرفع صوره",
    "price" => "السعر" ,
    "update" => "تحديث",
    "add" => "إضافه",
    "book" => "إضافه الي سلة",
    'remove' => 'أزاله من السلة',
    'quantity' => 'الكمية',

    "name_en" => "Name",
    "name_ar" => "الإسم",
    "desc_en" => "Description",
    "desc_ar" => "الوصف",
    "addImage" => 'اضف صور لخدمتك',
    'updateImages' => 'تحديث صور الخدمة',
    'serviceDeleteMsg' => 'تم حذف الخدمة بنجاح',
    'AddServMsg' => 'تم اضافة الخدمة بنجاح',
    'Delete' => 'حذف',

];