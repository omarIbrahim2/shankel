<?php
return[
    "comment" => "تعليق",
    "editComment" => "تعديل التعليق" ,
    "cls" => "إغلاق",
    "edit" => "تعديل",
    'deleteMsg' => "تم مسح التعليق بنجاح",
];