<?php

return [

"Home" => "الرئيسية",
"Profile" => "الصفحة الشخصية",
"Schools" => "المدارس",
"Teachers" => "المعلمين",
"Suppliers" => "الموردين",
"Services" => "الخدمات",
"Events" => "الفاعليات",
"Addverts" => "الإعلانات",
'dash' => "لوحة التحكم",
];