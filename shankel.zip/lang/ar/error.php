<?php

return [
 
    'errorMsg' => 'حدث خطأ ..!!',
 

];