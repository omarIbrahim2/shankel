<?php

return[

  "updateMsg" => 'تم تحديث بنجاح',

];