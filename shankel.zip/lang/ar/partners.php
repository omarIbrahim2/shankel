<?php

return [
"partners" => "الشركاء",

];