<?php

return [

   "Sign Up" => "انشاء حساب",

   "name" => "الاسم",

   "email" => "الايميل",

   "password" => "كلمة السر",

   "confirm_password" => "تأكيد كلمة السر",

   "phone" => "الهاتف",

   "city" => "المدينة",

   'area' => "المنطقة",

   "title" => "العنوان",

   "price" => "السعر",

   "subject" => 'المادة',

   "Add Child" => "اضافة طفل",

   "changepass" => "تم تغيير الباسورد بنجاح",

   "selectUser" => "اختار مستخدم",

   "Parent" => 'ولي أمر',

   "Teacher" => "معلم",

   "Supplier" => "مورد",


   "LoginToShankl" => "تسجيل الدخول الي شنكل",
   "School" => "مدرسة",
   "kg" => "رياض أطفال",

   "ClickHere" => "اضغط هنا",

   "center" => "مركز تعليمى",

   "nursery" => "حضانه",

   "signUpAs" => "إنشاء حساب ك",








];
